﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingSpree.Common
{
    public static class GlobalConstans
    {
        public const string EmptyNameConsMsg = "Name cannot be empty";

        public const string NegativeMoneMsg = "Money cannot be negative";
    }
}
